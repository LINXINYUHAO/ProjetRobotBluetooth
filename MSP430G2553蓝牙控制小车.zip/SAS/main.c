#include <msp430g2553.h>
#include "HC06.h"
volatile unsigned char temp='0',i;

int main(void) {
	Init_HC06();
    P1DIR |= BIT3 + BIT4 +BIT0 +BIT6;
    P1OUT &= ~(BIT3+BIT4+BIT0+BIT6);
    while(1)
    {
    	temp=UartGetchar();
    	if(temp=='4')
    	{
    		P1OUT |= BIT3+BIT0;
    		for(i=30000;i>0;i--);
    	}
    	else if (temp=='6')
    	{
    		P1OUT |= BIT4+BIT6;
    		for(i=30000;i>0;i--);
    	}
    	P1OUT &= ~(BIT3+BIT4+BIT0 +BIT6);
    }
    return 0; 
}


